﻿using System;
using System.Collections.Generic;
using TRG.Modelos;

namespace TRG.Servicios
{
    public class HTSvc
    {
        private List<Trnsc> hT = new List<Trnsc>();

        public void RgtrTrnsc(List<Prd> prds, decimal ttl)
        {
            hT.Add(new Trnsc(prds, ttl));
        }

        public List<Trnsc> ObtHT()
        {
            return hT;
        }
    }
}
