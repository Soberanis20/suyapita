﻿using System;
using System.Collections.Generic;
using System.Linq;
using TRG.Modelos;

namespace TRG.Servicios
{
    public class ISvc
    {
        private List<Prd> prds = new List<Prd>();

        public ISvc()
        {
            prds.Add(new Prd("Smartphones", 800.00m, 30));
            prds.Add(new Prd("Laptops", 1200.00m, 15));
            prds.Add(new Prd("Tablets", 600.00m, 25));
            prds.Add(new Prd("Smartwatches", 250.00m, 40));
            prds.Add(new Prd("Auriculares Bluetooth", 150.00m, 50));
            prds.Add(new Prd("Teclados mecánicos", 100.00m, 20));
            prds.Add(new Prd("Monitores 4K", 400.00m, 10));
            prds.Add(new Prd("Sillas ergonómicas", 300.00m, 15));
            prds.Add(new Prd("Impresoras 3D", 1000.00m, 5));
            prds.Add(new Prd("Cámaras DSLR", 1500.00m, 8));
            prds.Add(new Prd("Drones", 2000.00m, 6));
            prds.Add(new Prd("Consolas de videojuegos", 500.00m, 20));
            prds.Add(new Prd("Controles de videojuegos", 60.00m, 50));
            prds.Add(new Prd("Ratones inalámbricos", 40.00m, 60));
            prds.Add(new Prd("Altavoces portátiles", 80.00m, 30));
            prds.Add(new Prd("Proyectores HD", 600.00m, 10));
            prds.Add(new Prd("Tarjetas gráficas", 700.00m, 12));
            prds.Add(new Prd("Discos duros externos", 120.00m, 25));
        }

        public List<Prd> ObtInv()
        {
            return prds;
        }

        public void AgrPrd(Prd prd)
        {
            prds.Add(prd);
        }

        public bool ElmPrd(string nomPrd)
        {
            var prd = prds.FirstOrDefault(p => p.Nom == nomPrd);
            if (prd != null)
            {
                prds.Remove(prd);
                return true;
            }
            return false;
        }

        public bool ActInv(string nomPrd, int nuevaCnt)
        {
            var prd = prds.FirstOrDefault(p => p.Nom == nomPrd);
            if (prd != null)
            {
                prd.Cant = nuevaCnt;
                return true;
            }
            return false;
        }
    }
}
