﻿using System;
using System.Linq;
using System.Collections.Generic;
using TRG.Modelos;
using TRG.Servicios;

namespace TRG
{
    class Pgm
    {
        static ISvc iSvc = new ISvc();
        static CCpSvc cCpSvc = new CCpSvc();
        static HTSvc hTSvc = new HTSvc();

        static void Main(string[] args)
        {
            bool ejc = true;

            while (ejc)
            {
                MstrMnuPpl();
                int opc = Convert.ToInt32(Console.ReadLine());

                switch (opc)
                {
                    case 1:
                        MnuAgrPrd();
                        break;
                    case 2:
                        MnuElmPrd();
                        break;
                    case 3:
                        MnuActInv();
                        break;
                    case 4:
                        MnuRlzCmp();
                        break;
                    case 5:
                        VrHT();
                        break;
                    case 6:
                        ejc = false;
                        break;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }
            }
        }

        static void MstrMnuPpl()
        {
            Console.WriteLine("\n--- Mnu Ppl ---");
            Console.WriteLine("1. Agr Prd");
            Console.WriteLine("2. Elm Prd");
            Console.WriteLine("3. Act Inv");
            Console.WriteLine("4. Rlz Cmp");
            Console.WriteLine("5. Vr HT");
            Console.WriteLine("6. Slr");
            Console.Write("Sel opc: ");
        }

        static void MnuAgrPrd()
        {
            Console.Write("Nom prd: ");
            string nom = Console.ReadLine();

            Console.Write("Prec prd: ");
            decimal prec = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Cant prd: ");
            int cant = Convert.ToInt32(Console.ReadLine());

            iSvc.AgrPrd(new Prd(nom, prec, cant));
            Console.WriteLine("Prd agr.");
        }

        static void MnuElmPrd()
        {
            Console.Write("Nom prd elm: ");
            string nom = Console.ReadLine();

            iSvc.ElmPrd(nom);
            Console.WriteLine("Prd elm.");
        }

        static void MnuActInv()
        {
            Console.Write("Nom prd act: ");
            string nom = Console.ReadLine();

            Console.Write("Nuevo prec: ");
            decimal prec = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Nueva cant: ");
            int cant = Convert.ToInt32(Console.ReadLine());

            iSvc.ActPrd(nom, prec, cant);
            Console.WriteLine("Prd act.");
        }

        static void MnuRlzCmp()
        {
            Console.Write("Nom prd cmp: ");
            string nom = Console.ReadLine();

            Console.Write("Cant cmp: ");
            int cant = Convert.ToInt32(Console.ReadLine());

            cCpSvc.AgrAlCrt(nom, cant);
            Console.WriteLine("Prd agr al crt.");

            Console.Write("¿Proc con cmp? (S/N): ");
            string rsp = Console.ReadLine();

            if (rsp.ToUpper() == "S")
            {
                cCpSvc.RlzCmp();
                Console.WriteLine("Cmp rlz.");
            }
            else
            {
                Console.WriteLine("Cmp canc.");
            }
        }

        static void VrHT()
        {
            List<Trnsc> trns = hTSvc.ObtHT();

            Console.WriteLine("\n--- HT ---");
            foreach (var trn in trns)
            {
                Console.WriteLine($"Fch: {trn.Fch}, Prd: {trn.Prd}, Cant: {trn.Cant}, Ttl: {trn.Ttl}");
            }
        }
    }
}
