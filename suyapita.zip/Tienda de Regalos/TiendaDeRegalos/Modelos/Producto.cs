﻿using System;

namespace TRG.Modelos
{
    public class Prd
    {
        public string Nom { get; set; }
        public decimal Prc { get; set; }
        public int Cnt { get; set; }

        public Prd(string nom, decimal prc, int cnt)
        {
            Nom = nom;
            Prc = prc;
            Cnt = cnt;
        }

        public override string ToString()
        {
            return $"{Nom} - Precio: Q{Prc}, Cantidad: {Cnt}";
        }
    }
}
