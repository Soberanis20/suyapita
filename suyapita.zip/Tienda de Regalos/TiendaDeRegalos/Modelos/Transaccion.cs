﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TRG.Modelos
{
    public class Trnsc
    {
        public List<Prd> Prds { get; set; }
        public DateTime Fch { get; set; }
        public decimal Ttl { get; set; }

        public Trnsc(List<Prd> prds, decimal ttl)
        {
            Prds = prds;
            Fch = DateTime.Now;
            Ttl = ttl;
        }

        public override string ToString()
        {
            string prdsComprados = string.Join(", ", Prds.Select(p => $"{p.Nom} x {p.Cnt}"));
            return $"Fecha: {Fch}, Productos: {prdsComprados}, Total: Q{Ttl}";
        }
    }
}
