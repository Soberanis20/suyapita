using TiendaDeRegalos.Servicios;
using TiendaDeRegalos.Modelos;
using NUnit.Framework;
using System.Collections.Generic;

namespace TiendaDeRegalos.Tests
{
    [TestFixture]
    public class TiendaDeRegalosTests
    {
        private InventarioService inventarioService;
        private CarritoCompraService carritoCompraService;
        private HistorialTransaccionesService historialTransaccionesService;

        [SetUp]
        public void SetUp()
        {
            inventarioService = new InventarioService();
            carritoCompraService = new CarritoCompraService();
            historialTransaccionesService = new HistorialTransaccionesService();
        }

        [Test]
        public void AgregarProducto_DeberiaAgregarProductoAlInventario()
        {
            // Arrange
            var producto = new Producto("HotWheels", 20, 10);

            // Act
            inventarioService.AgregarProducto(producto);

            // Assert
            var inventario = inventarioService.ObtenerInventario();
            Assert.IsTrue(inventario.Exists(p => p.Nombre == "HotWheels"));
        }

        [Test]
        public void EliminarProducto_DeberiaEliminarProductoDelInventario()
        {
            // Arrange
            var producto = new Producto("HotWheels", 20, 10);
            inventarioService.AgregarProducto(producto);

            // Act
            bool resultado = inventarioService.EliminarProducto("HotWheels");

            // Assert
            Assert.IsTrue(resultado);
            var inventario = inventarioService.ObtenerInventario();
            Assert.IsFalse(inventario.Exists(p => p.Nombre == "HotWheels"));
        }

        [Test]
        public void ActualizarProducto_DeberiaActualizarLaCantidadDeProducto()
        {
            // Arrange
            var producto = new Producto("HotWheels", 20, 10);
            inventarioService.AgregarProducto(producto);

            // Act
            bool resultado = inventarioService.ActualizarInventario("HotWheels", 15);

            // Assert
            Assert.IsTrue(resultado);
            var productoActualizado = inventarioService.ObtenerInventario().Find(p => p.Nombre == "HotWheels");
            Assert.AreEqual(15, productoActualizado.Cantidad);
        }

        [Test]
        public void RealizarCompra_DeberiaDescontarCantidadDelInventarioYRegistrarTransaccion()
        {
            // Arrange
            var producto = new Producto("HotWheels", 20, 10);
            inventarioService.AgregarProducto(producto);
            carritoCompraService.AgregarAlCarrito(producto, 5);

            // Act
            decimal total = carritoCompraService.CalcularTotal();
            historialTransaccionesService.RegistrarTransaccion(carritoCompraService.ObtenerCarrito(), total);
            carritoCompraService.VaciarCarrito();

            // Assert
            Assert.AreEqual(112, total); // 5 unidades a Q20, con 12% de impuestos.
            Assert.AreEqual(5, inventarioService.ObtenerInventario().Find(p => p.Nombre == "HotWheels").Cantidad);
        }

        [Test]
        public void VerHistorialTransacciones_DeberiaRegistrarTransaccionDespuesDeCompra()
        {
            // Arrange
            var producto = new Producto("HotWheels", 20, 10);
            inventarioService.AgregarProducto(producto);
            carritoCompraService.AgregarAlCarrito(producto, 5);
            decimal total = carritoCompraService.CalcularTotal();

            // Act
            historialTransaccionesService.RegistrarTransaccion(carritoCompraService.ObtenerCarrito(), total);

            // Assert
            var historial = historialTransaccionesService.ObtenerHistorial();
            Assert.IsNotEmpty(historial);
            Assert.AreEqual(1, historial.Count);
        }

        [Test]
        public void CompraDeProductoNoDisponible_DeberiaLanzarExcepcionSiElProductoNoExiste()
        {
            // Act & Assert
            Assert.Throws<KeyNotFoundException>(() => carritoCompraService.AgregarAlCarrito(new Producto("NoExiste", 0, 0), 1));
        }

        [Test]
        public void CompraConCantidadExcedente_DeberiaLanzarExcepcionSiLaCantidadEsMayorQueElInventario()
        {
            // Arrange
            var producto = new Producto("HotWheels", 20, 5);
            inventarioService.AgregarProducto(producto);

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() => carritoCompraService.AgregarAlCarrito(producto, 10));
        }
    }
}
